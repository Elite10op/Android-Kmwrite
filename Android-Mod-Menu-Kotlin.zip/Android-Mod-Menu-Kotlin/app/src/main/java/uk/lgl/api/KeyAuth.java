package uk.lgl.api;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.Settings;
import android.widget.Toast;


import org.json.JSONObject;


import com.mashape.relocation.client.HttpClient;
import com.mashape.relocation.conn.ssl.SSLConnectionSocketFactory;
import com.mashape.relocation.impl.client.CloseableHttpClient;
import com.mashape.relocation.impl.client.HttpClients;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import uk.lgl.modmenu.FloatingModMenuService;
import uk.lgl.user.UserData;
import uk.lgl.util.HWID;

public class KeyAuth {

	public final String appname;
	public final String ownerid;
	public final String version;
	public final String url;

	protected String sessionid;
	protected boolean initialized;
	private ProgressDialog pDialog;

	protected UserData userData;

	public KeyAuth(String appname, String ownerid, String version, String url) {
		this.appname = appname;
		this.ownerid = ownerid;
		this.version = version;
		this.url = url;
	}

	public UserData getUserData() {
		return userData;
	}

	static {
		try {
			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				public void checkClientTrusted(X509Certificate[] certs, String authType) {
				}

				public void checkServerTrusted(X509Certificate[] certs, String authType) {
				}

			} };

			SSLContext sslcontext = SSLContext.getInstance("SSL");
			sslcontext.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sslcontext.getSocketFactory());
			SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext);
			CloseableHttpClient httpclient = HttpClients.custom().setSSLSocketFactory(sslsf).build();
			Unirest.setHttpClient((HttpClient) httpclient);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void init(Context a) {
		HttpResponse<String> response;
		pDialog = new ProgressDialog(a);
		pDialog.setCancelable(false);
		TrustManager[] trustManagerArr = {new X509TrustManager() {
			public void checkClientTrusted(X509Certificate[] x509CertificateArr, String str) {
			}

			public void checkServerTrusted(X509Certificate[] x509CertificateArr, String str) {
			}

			public X509Certificate[] getAcceptedIssuers() {
				return null;
			}
		}};
		try {
			SSLContext instance = SSLContext.getInstance("TLS");
			KeyManager[] keyManagerArr = null;
			instance.init((KeyManager[]) null, trustManagerArr, new SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(instance.getSocketFactory());
		} catch (KeyManagementException | NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

		StrictMode.setThreadPolicy(policy);
		try {
			response = Unirest.post(url).field("type", "init").field("ver", version).field("name", appname)
					.field("ownerid", ownerid).asString();

			try {
				JSONObject responseJSON = new JSONObject(response.getBody());
				if (response.getBody().equalsIgnoreCase("KeyAuth_Invalid")) {
					// Calling the method with a disabled connection
					// System.exit(0);
					System.out.println("invalid");
				}

				if (responseJSON.getBoolean("success")) {

					sessionid = responseJSON.getString("sessionid");
					initialized = true;
					System.out.println("Session ID: " + responseJSON.getString("sessionid"));

				} else if (responseJSON.getString("message").equalsIgnoreCase("invalidver")) {
					// Calling the method with a disabled version
					// System.out.println(reponseJSON.getString("download"));

				} else {
					System.out.println(responseJSON.getString("message"));
					// System.exit(0);
				}

			} catch (Exception e) {

			}
		} catch (UnirestException e) {
			e.printStackTrace();
		}
	}

	public void login(String username, String password, Context a) {
		if (!initialized) {
			Toast.makeText(a,"Please initzalize first".toString(),Toast.LENGTH_LONG).show();
			return;
		}
		pDialog.setMessage("Logging in...");
		pDialog.show();

		HttpResponse<String> response;
		try {
			String hwid = HWID.getHWID();

			response = Unirest.post(url).field("type", "login").field("username", username).field("pass", password)
					.field("hwid", hwid).field("sessionid", sessionid).field("name", appname).field("ownerid", ownerid)
					.asString();
			try {
				pDialog.dismiss();
				JSONObject responseJSON = new JSONObject(response.getBody());

				if (!responseJSON.getBoolean("success")) {
					AlertDialog dialog = new AlertDialog.Builder(a).setMessage(responseJSON.getString("message")).setTitle("Failed").setCancelable(false).setNegativeButton("OK",(dialogInterface, i) -> {
						System.exit(0);
					}).show();
				} else {
					userData = new UserData(responseJSON);
					Start(a);
				}

			} catch (Exception e) {

			}
		} catch (UnirestException e) {
			e.printStackTrace();
		}
	}

	public static void Start(final Context context) {
		//Check if overlay permission is enabled or not
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
			Toast.makeText(context.getApplicationContext(), "Overlay permission is required in order to show mod menu. Restart the game after you allow permission", Toast.LENGTH_LONG).show();
			Toast.makeText(context.getApplicationContext(), "Overlay permission is required in order to show mod menu. Restart the game after you allow permission", Toast.LENGTH_LONG).show();
			context.startActivity(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION",
					Uri.parse("package:" + context.getPackageName())));
			final Handler handler = new Handler();
			handler.postDelayed(new Runnable() {
				@Override
				public void run() {
					System.exit(1);
				}
			}, 5000);
			return;
		} else {
			final Handler handler = new Handler();
			handler.postDelayed(new Runnable() {
				@Override
				public void run() {
					context.startService(new Intent(context, FloatingModMenuService.class));
				}
			}, 500);
		}
	}
}
