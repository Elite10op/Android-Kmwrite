package uk.lgl.user;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class UserData {

	private static String username;
	private static String subscription;
	private static String expiry;

	public UserData(JSONObject json) throws JSONException {
		JSONObject info = json.getJSONObject("info");

		JSONArray subArray = info.getJSONArray("subscriptions");
		JSONObject subObject = subArray.getJSONObject(0);
		
		this.username = info.getString("username");
		this.subscription = subObject.getString("subscription");
		this.expiry = subObject.getString("expiry");
	}

	public static String getUsername() {
		return username;
	}

	public static String getSubscription() {
		return subscription;
	}

	public static String getExpiry() {
		return expiry;
	}

}
