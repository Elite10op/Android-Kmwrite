package uk.lgl;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.Base64;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.UUID;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.net.ConnectivityManager;
import android.widget.CheckBox;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.util.Base64;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.security.Certificate;
import java.security.MessageDigest;
import android.os.Environment;

import uk.lgl.api.KeyAuth;
import uk.lgl.modmenu.FloatingModMenuService;

public class MainActivity extends Activity {

    private static String ownerid = "mzeXHltSum"; // You can find out the owner id in the profile settings keyauth.com
    private static String appname = "win"; // Application name
    private static String version = "1.0"; // Application version
    private static String url = "https://keyauth.win/api/1.1/";
    Context context;
    private static KeyAuth keyAuth = new KeyAuth(appname, ownerid, version, url);
    //To call onCreate, please refer to README.md
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        System.loadLibrary("MyLibName");
        context = this;
        keyAuth.init(this);
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        float f = context.getResources().getDisplayMetrics().density;
        LinearLayout linearLayout = new LinearLayout(context);
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -2);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setLayoutParams(layoutParams);
        TextView imageView = new TextView(context);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, 1);
        layoutParams2.width = -1;
        layoutParams2.height = (int) (200);
        imageView.setBackgroundColor(Color.parseColor("#FFFFFF"));
        String str2 = new String("MUSKMODS");
        imageView.setText(str2);
        imageView.setGravity(Gravity.CENTER);
       // imageView.setScaleType(ImageView.ScaleType.CENTER);
         linearLayout.addView(imageView);
        imageView.setLayoutParams(layoutParams2);


        final EditText editText = new EditText(context);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams3.width = -1;
        layoutParams3.leftMargin = (int) ((f * 4.0f) + 0.5f);
        layoutParams3.topMargin = (int) ((16.0f * f) + 0.5f);
        layoutParams3.rightMargin = (int) ((f * 4.0f) + 0.5f);
        layoutParams3.bottomMargin = (int) ((f * 4.0f) + 0.5f);
        String str3 = new String("User");
        editText.setHint(str3);
        editText.setRawInputType(1);
        editText.setTextColor(Color.BLACK);
        editText.setHintTextColor(Color.parseColor("#000000"));
        linearLayout.addView(editText);
        editText.setLayoutParams(layoutParams3);

   final EditText editText2 = new EditText(context);
        LinearLayout.LayoutParams layoutParams32 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams32.width = -1;
        layoutParams32.leftMargin = (int) ((f * 4.0f) + 0.5f);
        layoutParams32.topMargin = (int) ((16.0f * f) + 0.5f);
        layoutParams32.rightMargin = (int) ((f * 4.0f) + 0.5f);
        layoutParams32.bottomMargin = (int) ((f * 4.0f) + 0.5f);
        String str32 = new String("Pass");
        editText2.setHint(str32);
        editText2.setRawInputType(1);
        editText2.setTextColor(Color.BLACK);
        editText2.setHintTextColor(Color.parseColor("#000000"));
        linearLayout.addView(editText2);
        editText2.setLayoutParams(layoutParams32);

        builder.setCancelable(false);
        builder.setView(linearLayout);
        builder.setPositiveButton("Login", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                final String obj = editText.getText().toString();
                final String objx= editText2.getText().toString();
                keyAuth.login(obj,objx,context);
            }
        });
        builder.setNegativeButton("Youtube", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent ix = new Intent("android.intent.action.VIEW");
                ix.setData(Uri.parse("https://www.youtube.com/channel/UC2P8szhBq55bYtPeuvMVfBQ"));
                context.startActivity(ix);
            }
        });
        AlertDialog create = builder.create();
        create.show();
    }
}
